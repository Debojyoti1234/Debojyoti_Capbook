package com.cg.capbook.exceptions;

public class IncorrectAnswerException extends Exception {

	public IncorrectAnswerException() {
	
	System.out.println("your answer is incorrect");
	}

	public IncorrectAnswerException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public IncorrectAnswerException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public IncorrectAnswerException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public IncorrectAnswerException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

}
